Admin login:
username: admin
password: admin

Staff Login
Employee No: 34
surname: Billy
password: John