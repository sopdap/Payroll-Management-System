# payroll
This is a payroll system built in Php/Mysql and Ajax.
This web app records payment.

Check the readme text file inside to see Login Details

#Login
![payroll_login](https://cloud.githubusercontent.com/assets/586490/24569734/7bd09b0a-165f-11e7-9120-e6e7aadac7c0.png)

Admin Features:
<ul>
	<li>Add Employee</li>
	<li>Record Monthly Payments</li>
</ul>

User Features:
<ul>
	<li>View Payment</li>
</ul>

#Admin Page
![payroll_admin](https://cloud.githubusercontent.com/assets/586490/24569753/98d82cfe-165f-11e7-8f7c-f3414746df2d.png)

#Employee Page
![payroll_employee](https://cloud.githubusercontent.com/assets/586490/24569767/aefb34ae-165f-11e7-92d6-e0489d325ee0.png)
